package com.yatharth.dutchflashcards

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Orange = Color(0xFFFF6F00)
private val DarkBg = Color(0xFF121212)
private val CardBg = Color(0xFF1E1E1E)
private val TextPrimary = Color(0xFFF5F5F5)
private val TextSecondary = Color(0xFFB0BEC5)
private val WarnAmber = Color(0xFFFFB74D)

private fun openTtsSettings(context: Context) {
    try {
        context.startActivity(
            Intent("com.android.settings.TTS_SETTINGS")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: ActivityNotFoundException) {
        // Settings screen not available on this device; nothing sensible to do.
    }
}

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep the screen on during listening sessions.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Orange,
                    background = DarkBg,
                    surface = CardBg
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = DarkBg) {
                    PlayerScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(viewModel: PlayerViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val inPreviousWindow by viewModel.inPreviousWindow.collectAsStateWithLifecycle()
    val context = LocalContext.current

    when (state.phase) {
        Phase.LOADING -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Orange)
            }
            return
        }
        Phase.TTS_ERROR -> {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "Text-to-speech is not available on this device.\n" +
                        "Install Google Speech Services, then try again.",
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { openTtsSettings(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = CardBg, contentColor = TextPrimary)
                ) { Text("Open TTS settings") }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { viewModel.retryTts() },
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.White)
                ) { Text("Try again") }
            }
            return
        }
        else -> Unit
    }

    val card = state.card ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(20.dp)
    ) {
        // Top row: title, shuffle + speed controls, progress counter
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Dutch 🇳🇱", color = TextSecondary, fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Text(
                "🔀",
                fontSize = 16.sp,
                color = if (state.shuffle) Orange else TextSecondary,
                modifier = Modifier
                    .clickable { viewModel.toggleShuffle() }
                    .padding(horizontal = 6.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = when (state.speed) {
                    0.75f -> "0.75×"
                    1.25f -> "1.25×"
                    else -> "1×"
                },
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (state.speed != 1.0f) Orange else TextSecondary,
                modifier = Modifier
                    .clickable { viewModel.cycleSpeed() }
                    .padding(horizontal = 6.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "${state.index + 1} / ${state.total}",
                color = TextSecondary,
                fontSize = 14.sp
            )
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { (state.index + 1).toFloat() / state.total },
            modifier = Modifier.fillMaxWidth(),
            color = Orange,
            trackColor = CardBg
        )

        if (state.dutchVoiceMissing) {
            Spacer(Modifier.height(8.dp))
            Text(
                "⚠️ Dutch voice not installed — tap here to open text-to-speech settings.",
                color = WarnAmber,
                fontSize = 12.sp,
                modifier = Modifier.clickable { openTtsSettings(context) }
            )
        }

        // Card (tap to pause/resume)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 24.dp)
                .background(CardBg, RoundedCornerShape(24.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { viewModel.togglePause() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = card.nl,
                    color = if (state.phase == Phase.SPEAKING_NL) Orange else TextPrimary,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    lineHeight = 48.sp
                )
                Spacer(Modifier.height(24.dp))
                Text(
                    text = card.en,
                    color = if (state.phase == Phase.SPEAKING_EN) Orange else TextSecondary,
                    fontSize = 26.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 34.sp
                )
                if (state.phase == Phase.PAUSED) {
                    Spacer(Modifier.height(32.dp))
                    Text("⏸ Paused — tap to resume", color = TextSecondary, fontSize = 14.sp)
                }
            }
        }

        // Two-button interface
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { viewModel.repeatOrPrevious() },
                modifier = Modifier
                    .weight(1f)
                    .height(72.dp),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CardBg,
                    contentColor = TextPrimary
                )
            ) {
                Text(
                    if (inPreviousWindow && state.index > 0) "←  Previous" else "↻  Repeat",
                    fontSize = 20.sp
                )
            }
            Button(
                onClick = { viewModel.skip() },
                modifier = Modifier
                    .weight(1f)
                    .height(72.dp),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Orange,
                    contentColor = Color.White
                )
            ) {
                Text("Skip  →", fontSize = 20.sp)
            }
        }
    }
}
