package com.yatharth.dutchflashcards

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Thin coroutine wrapper around Android's on-device TextToSpeech.
 * Speaks Dutch (nl-NL) and English (en-US) using the system TTS engine.
 */
class TtsManager(context: Context) {

    private val readyDeferred = CompletableDeferred<Boolean>()
    private val utteranceCounter = AtomicInteger(0)
    @Volatile private var currentContinuation: kotlinx.coroutines.CancellableContinuation<Unit>? = null
    @Volatile private var currentUtteranceId: String? = null

    var dutchAvailable: Boolean = true
        private set

    /** Re-checks Dutch voice availability (e.g. after the user visits TTS settings). */
    fun refreshDutchAvailability(): Boolean {
        if (readyDeferred.isCompleted) {
            dutchAvailable = tts.isLanguageAvailable(DUTCH) >= TextToSpeech.LANG_AVAILABLE
        }
        return dutchAvailable
    }

    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        readyDeferred.complete(status == TextToSpeech.SUCCESS)
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                finish(utteranceId)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish(utteranceId)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                finish(utteranceId)
            }

            private fun finish(utteranceId: String?) {
                if (utteranceId != null && utteranceId == currentUtteranceId) {
                    currentUtteranceId = null
                    currentContinuation?.let { cont ->
                        currentContinuation = null
                        if (cont.isActive) cont.resume(Unit)
                    }
                }
            }
        })
    }

    /** Waits until the TTS engine is initialised. Returns false on failure. */
    suspend fun awaitReady(): Boolean {
        val ok = readyDeferred.await()
        if (ok) {
            dutchAvailable =
                tts.isLanguageAvailable(DUTCH) >= TextToSpeech.LANG_AVAILABLE
        }
        return ok
    }

    /**
     * Speaks [text] in [locale] and suspends until playback finishes.
     * Cancelling the coroutine stops playback immediately.
     */
    suspend fun speak(text: String, locale: Locale, rate: Float = 0.9f) {
        tts.language = locale
        tts.setSpeechRate(rate)
        val id = "utt-${utteranceCounter.incrementAndGet()}"

        suspendCancellableCoroutine { cont ->
            currentContinuation = cont
            currentUtteranceId = id
            val result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            if (result != TextToSpeech.SUCCESS) {
                currentContinuation = null
                currentUtteranceId = null
                if (cont.isActive) cont.resume(Unit)
                return@suspendCancellableCoroutine
            }
            cont.invokeOnCancellation {
                currentContinuation = null
                currentUtteranceId = null
                tts.stop()
            }
        }
    }

    fun stop() {
        tts.stop()
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }

    companion object {
        val DUTCH: Locale = Locale("nl", "NL")
        val ENGLISH: Locale = Locale.US
    }
}
