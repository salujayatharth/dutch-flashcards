package com.yatharth.dutchflashcards

import android.app.Application
import android.content.Context
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Phase { LOADING, SPEAKING_NL, SPEAKING_EN, WAITING, PAUSED, TTS_ERROR }

data class PlayerState(
    val cards: List<Card> = emptyList(),
    /** Playback order: positions into [cards]. Identity order, or shuffled. */
    val order: List<Int> = emptyList(),
    val index: Int = 0,
    val phase: Phase = Phase.LOADING,
    val dutchVoiceMissing: Boolean = false,
    val shuffle: Boolean = false,
    val speed: Float = 1.0f
) {
    val card: Card? get() = order.getOrNull(index)?.let { cards.getOrNull(it) }
    val total: Int get() = cards.size
}

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    /** Pressing the left button within this window goes BACK instead of repeating. */
    private val previousWindowMs = 5_000L
    private val speedSteps = listOf(0.75f, 1.0f, 1.25f)

    private val prefs = app.getSharedPreferences("player", Context.MODE_PRIVATE)
    private var tts = TtsManager(app)

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private var playJob: Job? = null
    private var windowJob: Job? = null
    private var cardShownAt = 0L

    /** True while we are inside the "previous" window; drives the button label. */
    private val _inPreviousWindow = MutableStateFlow(false)
    val inPreviousWindow: StateFlow<Boolean> = _inPreviousWindow.asStateFlow()

    init {
        viewModelScope.launch {
            val cards = withContext(Dispatchers.IO) { CardRepository.load(app) }
            val shuffle = prefs.getBoolean("shuffle", false)
            val speed = prefs.getFloat("speed", 1.0f)
                .let { s -> speedSteps.minByOrNull { kotlin.math.abs(it - s) } ?: 1.0f }
            val savedIndex = prefs.getInt("index", 0).coerceIn(0, (cards.size - 1).coerceAtLeast(0))
            val ttsOk = tts.awaitReady()
            _state.update {
                it.copy(
                    cards = cards,
                    order = buildOrder(cards.size, shuffle),
                    index = savedIndex,
                    phase = if (ttsOk) Phase.WAITING else Phase.TTS_ERROR,
                    dutchVoiceMissing = ttsOk && !tts.dutchAvailable,
                    shuffle = shuffle,
                    speed = speed
                )
            }
            if (ttsOk) playCurrent()
        }
    }

    /** Deterministic shuffle so the order is stable across app restarts. */
    private fun buildOrder(size: Int, shuffle: Boolean): List<Int> {
        val order = (0 until size).toMutableList()
        if (shuffle) {
            val seed = prefs.getLong("shuffleSeed", 0L).let {
                if (it != 0L) it else Random.nextLong().also { s ->
                    prefs.edit().putLong("shuffleSeed", s).apply()
                }
            }
            order.shuffle(Random(seed))
        }
        return order
    }

    private fun playCurrent() {
        playJob?.cancel()

        // Track the "previous" window independently of playback.
        cardShownAt = SystemClock.elapsedRealtime()
        _inPreviousWindow.value = true
        windowJob?.cancel()
        windowJob = viewModelScope.launch {
            delay(previousWindowMs)
            _inPreviousWindow.value = false
        }

        playJob = viewModelScope.launch {
            val card = _state.value.card ?: return@launch
            val speed = _state.value.speed

            // Clears the "install Dutch voice" banner once the user has installed it.
            val dutchMissing = !tts.refreshDutchAvailability()
            if (dutchMissing != _state.value.dutchVoiceMissing) {
                _state.update { it.copy(dutchVoiceMissing = dutchMissing) }
            }

            _state.update { it.copy(phase = Phase.SPEAKING_NL) }
            tts.speak(card.nl, TtsManager.DUTCH, rate = 0.85f * speed)
            delay(400)

            _state.update { it.copy(phase = Phase.SPEAKING_EN) }
            tts.speak(card.en, TtsManager.ENGLISH, rate = 1.0f * speed)

            _state.update { it.copy(phase = Phase.WAITING) }
            delay(1500)
            goTo(_state.value.index + 1)
        }
    }

    /** Left button: previous card if pressed shortly after the card appeared, otherwise repeat. */
    fun repeatOrPrevious() {
        val withinWindow = SystemClock.elapsedRealtime() - cardShownAt < previousWindowMs
        if (withinWindow && _state.value.index > 0) {
            goTo(_state.value.index - 1)
        } else {
            playCurrent()
        }
    }

    /** Right button: next card. */
    fun skip() {
        goTo(_state.value.index + 1)
    }

    /** Tap on the card toggles pause/resume. */
    fun togglePause() {
        if (_state.value.phase == Phase.PAUSED) {
            playCurrent()
        } else {
            playJob?.cancel()
            windowJob?.cancel()
            _inPreviousWindow.value = false // keep label consistent with time-based check
            tts.stop()
            _state.update { it.copy(phase = Phase.PAUSED) }
        }
    }

    /** Cycles 0.75× → 1× → 1.25×. Takes effect from the next utterance. */
    fun cycleSpeed() {
        val current = _state.value.speed
        val next = speedSteps[(speedSteps.indexOf(current) + 1) % speedSteps.size]
        prefs.edit().putFloat("speed", next).apply()
        _state.update { it.copy(speed = next) }
    }

    /** Toggles shuffled playback order (deterministic across restarts). */
    fun toggleShuffle() {
        val newShuffle = !_state.value.shuffle
        prefs.edit().putBoolean("shuffle", newShuffle).apply()
        _state.update {
            it.copy(shuffle = newShuffle, order = buildOrder(it.cards.size, newShuffle))
        }
        playCurrent()
    }

    /** Retry TTS initialisation after the user installs an engine/voice. */
    fun retryTts() {
        viewModelScope.launch {
            var ok = tts.awaitReady()
            if (!ok) {
                // The old engine failed to initialise; a fresh instance is required.
                tts.shutdown()
                tts = TtsManager(getApplication())
                ok = tts.awaitReady()
            }
            _state.update {
                it.copy(
                    phase = if (ok) Phase.WAITING else Phase.TTS_ERROR,
                    dutchVoiceMissing = ok && !tts.dutchAvailable
                )
            }
            if (ok) playCurrent()
        }
    }

    private fun goTo(newIndex: Int) {
        val total = _state.value.total
        if (total == 0) return
        val idx = ((newIndex % total) + total) % total // wrap around both ways
        _state.update { it.copy(index = idx) }
        prefs.edit().putInt("index", idx).apply()
        playCurrent()
    }

    override fun onCleared() {
        playJob?.cancel()
        windowJob?.cancel()
        tts.shutdown()
    }
}
