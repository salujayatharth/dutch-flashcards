package com.yatharth.dutchflashcards

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

@Serializable
data class Card(
    val nl: String,
    val en: String
)

object CardRepository {
    private val json = Json { ignoreUnknownKeys = true }

    fun load(context: Context): List<Card> =
        context.assets.open("cards.json").bufferedReader().use { reader ->
            json.decodeFromString<List<Card>>(reader.readText())
        }
}
